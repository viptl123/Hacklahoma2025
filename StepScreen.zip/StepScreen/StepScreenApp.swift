//
//  StepScreenApp.swift
//  StepScreen
//
//  Created by Arman Riaz on 2/15/25.
//

import SwiftUI

@main
struct StepScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
